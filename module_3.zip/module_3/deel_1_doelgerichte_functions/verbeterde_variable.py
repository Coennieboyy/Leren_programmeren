# gaat kijken of het deelbaar is door 2
def Deelbaar_Door_2(getal:int) -> bool:
    return getal % 2 == 0

# draait de zin om
def Zin_Omdraaier(zin:str) -> str:
    woordlijst = zin.split()
    zinomdraaien = woordlijst[::-1]
    nieuwezin = ' '.join(zinomdraaien)
    return nieuwezin

# telt de letters in de zin of woord
def Letter_Teller(woorden:str) -> int:
    woorden_lijst = set(woorden)
    Hoeveel_letters = len(woorden_lijst)
    return Hoeveel_letters 

# berekend gemiddelde letters per woord
def Gemiddelde_Letters_Per_Woord(woorden:str) -> float:
    woordenlijst = woorden.split()
    
    totaleletters = 0
    for woord in woordenlijst:
        totaleletters += len(woord)

    gemiddeldelijst = totaleletters / len(woordenlijst)
    return gemiddeldelijst

def Rekentafels(keergetal:int, maxgetal:int=10) -> None:
    for getal in range(1, maxgetal+1):
        antwoord = getal * keergetal
        print(f'{getal} x {keergetal} = {antwoord}')

print(Rekentafels(12))
def herhaling(getal):
    for i in range(1,getal+1):
        print(f"Hello from function town {i}!")

herhaling(3)
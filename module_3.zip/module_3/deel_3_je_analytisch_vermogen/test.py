import math

amount = 0.125
amount2 = math.floor(amount)
floatSom = amount2 % amount

print(floatSom)
mensen = int(input('aantal mannen?') + input('aantal vrouwen?'))
print(mensen)

